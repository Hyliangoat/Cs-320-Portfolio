package appointmentService;
import java.util.Date;
public class Appointment {
	
	private String appointmentID;
	private Date appointmentDate;
	private String description;
	
	public Appointment(String appointmentID, Date appointmentDate, String description) {
		if (appointmentID == null || appointmentID.length() > 10) {
			throw new IllegalArgumentException("Invalid Appointment ID");
		}
		
		if (appointmentDate == null || appointmentDate.before(new Date())) {
			throw new IllegalArgumentException("Invalid Appointment Date");
		}
		
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid Description");
		}
		
		this.appointmentID = appointmentID;
		this.appointmentDate = appointmentDate;
		this.description = description;
	}
	
	//My getters
	
	public String getAppointmentID() {
		return appointmentID;
	}
	
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	
	public String getDescription() {
		return description;
	}
	
	//My setters
	
	public void setAppointmentDate(Date appointmentDate) {
		if(appointmentDate ==  null || appointmentDate.before(new Date())) {
			throw new IllegalArgumentException("Invalid Appointment Date");
		}
		
		this.appointmentDate = appointmentDate;
	}
	
	public void setDescription(String description) {
		if(description ==  null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid Description");
		}
		
		this.description = description;
	}
}