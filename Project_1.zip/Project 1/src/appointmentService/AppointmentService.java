package appointmentService;
import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
	private Map<String, Appointment> appointments = new HashMap<>();
	
	public void addAppointment(Appointment appointment) {
		if (appointment == null) {
			throw new IllegalArgumentException("Appointment must not be empty.");
		}
		
		String id = appointment.getAppointmentID();
		
		if(appointments.containsKey(id)) {
			throw new IllegalArgumentException("Appointment ID already exists.");
		}
		
		appointments.put(id,  appointment);
	}
	
	public void deleteAppointment(String appointmentID) {
		appointments.remove(appointmentID);
	}
	
	public Appointment getAppointment(String appointmentID) {
		return appointments.get(appointmentID);
	}
}
