package contactService;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
	
	private Map<String, Contact> contacts = new HashMap<>();
	
	public void addContact(Contact contact) {
		if (contact == null) {
			throw new IllegalArgumentException("Contact can't be null");
		}
		
		String id = contact.getId();
		
		if(contacts.containsKey(id)) {
			throw new IllegalArgumentException("Contact ID already exists");
		}
		
		contacts.put(id,  contact);
	}
	
	public void deleteContact(String contactId) {
		if (contactId == null || !contacts.containsKey(contactId)) {
			throw new IllegalArgumentException("Contact ID does not exist");
		}
		
		contacts.remove(contactId);
	}
	
	public void updateFirstName(String contactId, String firstName) {
		Contact contact = getContactById(contactId);
		Contact updatedContact = new Contact(
				firstName,
				contact.getLastName(),
				contact.getId(),
				contact.getPhone(),
				contact.getAddress()
			);
		contacts.put(contactId,  updatedContact);
	}
	
	public void updateLastName(String contactId, String lastName) {
		Contact contact = getContactById(contactId);
		Contact updatedContact = new Contact(
				contact.getFirstName(),
				lastName,
				contact.getId(),
				contact.getPhone(),
				contact.getAddress()
			);
		contacts.put(contactId,  updatedContact);
	}
	
	public void updatePhone(String contactId, String phone) {
		Contact contact = getContactById(contactId);
		Contact updatedContact = new Contact(
				contact.getFirstName(),
				contact.getLastName(),
				contact.getId(),
				phone,
				contact.getAddress()
			);
		contacts.put(contactId,  updatedContact);
	}
	
	public void updateAddress(String contactId, String address) {
		Contact contact = getContactById(contactId);
		Contact updatedContact = new Contact(
				contact.getFirstName(),
				contact.getLastName(),
				contact.getId(),
				contact.getPhone(),
				address
			);
		contacts.put(contactId,  updatedContact);
	}
	
	private Contact getContactById(String contactId) {
		if (contactId == null || !contacts.containsKey(contactId)) {
			throw new IllegalArgumentException("Contact ID does not exist");
		}
		return contacts.get(contactId);
	}
	
	public Contact getContact(String contactID) {
		return getContactById(contactID);
	}
}
