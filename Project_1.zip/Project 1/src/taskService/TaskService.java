package taskService;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
	private Map<String, Task> tasks = new HashMap<>();
	
	public void addTask(Task task) {
		if (tasks.containsKey(task.getTaskID())) {
			throw new IllegalArgumentException("Task ID already exists");
		}
		tasks.put(task.getTaskID(), task);
	}
	
	public void deleteTask(String taskID) {
		if (!tasks.containsKey(taskID)) {
			throw new IllegalArgumentException("Task not found");
		}
		tasks.remove(taskID);
	}
	
	public void updateName(String taskID, String name) {
		Task task = tasks.get(taskID);
		if (task == null) {
			throw new IllegalArgumentException("Task not found");
		}
		task.setName(name);
	}
	
	public void updateDescription(String taskID, String description) {
		Task task = tasks.get(taskID);
		if (task == null) {
			throw new IllegalArgumentException("Task not found");
		}
		task.setDescription(description);
	}
}
