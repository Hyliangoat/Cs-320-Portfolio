package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import appointmentService.Appointment;
import appointmentService.AppointmentService;

import java.util.Date;
class AppointmentServiceTest {

	@Test
	void testAddAppointmentStoresDataCorrectly() {
		AppointmentService service = new AppointmentService();
		Date futureDate = new Date(System.currentTimeMillis()+ 100000);
		
		Appointment appointment = new Appointment("369", futureDate, "Serious Therapy");
		service.addAppointment(appointment);
		
		Appointment stored = service.getAppointment("369");
		
		assertNotNull(stored);
		assertEquals("369", stored.getAppointmentID());
		assertEquals("Serious Therapy", stored.getDescription());
	}
	
	@Test
	void testDeleteAppointmentActuallyRemovesIt() {
		AppointmentService service = new AppointmentService();
		Date futureDate = new Date(System.currentTimeMillis() + 100000);
		
		Appointment appointment = new Appointment("007", futureDate, "Yoga Sesh");
		service.addAppointment(appointment);
		
		assertNotNull(service.getAppointment("007"));
		service.deleteAppointment("007");
		assertNull(service.getAppointment("007"));
	}
	
	@Test
	void testDeleteDoesNotAffectOtherAppointments() {
		AppointmentService service = new AppointmentService();
		Date futureDate = new Date(System.currentTimeMillis() + 100000);
		
		Appointment appt1 = new Appointment("777", futureDate, "Brunch Date With Mom");
		Appointment appt2 = new Appointment("444", futureDate, "Brunch Date With Dad");
		
		service.addAppointment(appt1);
		service.addAppointment(appt2);
		
		service.deleteAppointment("777");
		
		assertNull(service.getAppointment("777"));
		assertNotNull(service.getAppointment("444"));
	}
	
	@Test
	void testDuplicateAppointmentIDNotAdded() {
		AppointmentService service = new AppointmentService();
		Date futureDate = new Date(System.currentTimeMillis() + 100000);
		
		Appointment first = new Appointment("999", futureDate, "First");
		Appointment second = new Appointment("999", futureDate, "Second");
		
		service.addAppointment(first);
		
		assertThrows(IllegalArgumentException.class, () -> {
			service.addAppointment(second);
		});
		
		Appointment stored = service.getAppointment("999");
		assertEquals("First", stored.getDescription());
	}
	
	@Test
	void testDeleteNonExistentDoesNothing() {
		AppointmentService service = new AppointmentService();
		
		service.deleteAppointment("Nada");
		
		assertNull(service.getAppointment("Nada"));
	}

}