package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import appointmentService.Appointment;
import appointmentService.AppointmentService;

import java.util.Date;
class AppointmentTest {

	@Test
	void testAppointmentFieldsSetCorrectly() {
		Date futureDate = new Date(System.currentTimeMillis() + 100000);
		Appointment appt = new Appointment("369", futureDate, "Serious Therapy");
		
		assertEquals("369", appt.getAppointmentID());
		assertEquals(futureDate, appt.getAppointmentDate());
		assertEquals("Serious Therapy", appt.getDescription());
	}
	
	@Test
	void testAppointmentDateCanBeUpdated() {
		Date futureDate = new Date(System.currentTimeMillis() + 100000);
		Date evenFurtherDate = new Date(System.currentTimeMillis() + 200000);
		
		Appointment appt = new Appointment("007", futureDate, "Yoga Sesh");
		appt.setAppointmentDate(evenFurtherDate);
		
		assertEquals(evenFurtherDate, appt.getAppointmentDate());
	}
	
	@Test
	void testDescriptionCanBeUpdated() {
		Date futureDate = new Date(System.currentTimeMillis() + 100000);
		Appointment appt = new Appointment("777", futureDate, "Brunch Date With Mom");
		
		appt.setDescription("Updated description");
		
		assertEquals("Updated description", appt.getDescription());
	}
	
	@Test
	void testSetAppointmentDateInvalidPastDate() {
		Date pastDate = new Date(System.currentTimeMillis() - 100000);
		Appointment appt = new Appointment("101", new Date(System.currentTimeMillis() + 100000), "Futureland");
		
		assertThrows(IllegalArgumentException.class, () -> appt.setAppointmentDate(pastDate));
	}
	
	@Test
	void testSetDescriptionTooLong() {
		Appointment appt = new Appointment("102", new Date(System.currentTimeMillis() + 100000), "Testing tiime");
		String longDescription = "How many characters can I write in this box? 50? Is it 50? Hey google how many characters can i write in this box. Wait let me ask Martha on facebook she will know. Java open facebook and ask martha how many characters";
		
		assertThrows(IllegalArgumentException.class, () -> appt.setDescription(longDescription));
	}
	
	@Test
	void testAddNullAppt() {
		AppointmentService service = new AppointmentService();
		
		assertThrows(IllegalArgumentException.class, () -> service.addAppointment(null));
	}

}
