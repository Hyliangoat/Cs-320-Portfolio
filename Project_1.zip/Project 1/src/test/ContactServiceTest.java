package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import contactService.Contact;
import contactService.ContactService;

class ContactServiceTest {

	@Test
	void testAddContact() {
		ContactService service = new ContactService();
		Contact contact = new Contact("Jimmy", "Fallon", "12345", "1112223333",
				"7 Maple Ave");
		service.addContact(contact);
		assertTrue(true);
	}
	
	@Test
	void testAddDuplicateContactId() {
		ContactService service = new ContactService();
		Contact contact = new Contact("Jimmy", "Fallon", "12345", "1112223333",
				"7 Maple Ave");
		
		service.addContact(contact);
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.addContact(contact);
		});
	}
	
	@Test
	void testDeleteContact() {
		ContactService service = new ContactService();
		Contact contact = new Contact("Jimmy", "Fallon", "12345", "1112223333",
				"7 Maple Ave");
		
		service.addContact(contact);
		service.deleteContact("12345");
		
		assertThrows(IllegalArgumentException.class, () -> {
			service.getContact("12345");
		});
	}
	
	@Test
	void testDeleteContactDoesNotExist() {
		ContactService service = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.deleteContact("54321");
		});
	}
	
	@Test
	void testUpdateFirstName() {
		ContactService service = new ContactService();
		Contact contact = new Contact("Jimmy", "Fallon", "12345", "1112223333",
				"7 Maple Ave");
		
		service.addContact(contact);
		service.updateFirstName("12345", "Jimothy");
		
		Contact updated = service.getContact("12345");
		assertEquals("Jimothy", updated.getFirstName());
		assertEquals("Fallon", updated.getLastName());
		assertEquals("1112223333", updated.getPhone());
		assertEquals("7 Maple Ave", updated.getAddress());
	}
	
	@Test
	void testUpdateLastName() {
		ContactService service = new ContactService();
		Contact contact = new Contact("Jimmy", "Fallon", "12345", "1112223333",
				"7 Maple Ave");
		
		service.addContact(contact);
		service.updateLastName("12345", "Kimmel");
		
		Contact updated = service.getContact("12345");
		assertEquals("Jimmy", updated.getFirstName());
		assertEquals("Kimmel", updated.getLastName());
		assertEquals("1112223333", updated.getPhone());
		assertEquals("7 Maple Ave", updated.getAddress());
	}
	
	@Test
	void testUpdatePhone() {
		ContactService service = new ContactService();
		Contact contact = new Contact("Jimmy", "Fallon", "12345", "1112223333",
				"7 Maple Ave");
		
		service.addContact(contact);
		service.updatePhone("12345", "2223334444");
		
		Contact updated = service.getContact("12345");
		assertEquals("Jimmy", updated.getFirstName());
		assertEquals("Fallon", updated.getLastName());
		assertEquals("2223334444", updated.getPhone());
		assertEquals("7 Maple Ave", updated.getAddress());
	}
	
	@Test
	void testUpdateAddress() {
		ContactService service = new ContactService();
		Contact contact = new Contact("Jimmy", "Fallon", "12345", "1112223333",
				"7 Maple Ave");
		
		service.addContact(contact);
		service.updateAddress("12345", "25 Ridgeway Pk");
		
		Contact updated = service.getContact("12345");
		assertEquals("Jimmy", updated.getFirstName());
		assertEquals("Fallon", updated.getLastName());
		assertEquals("1112223333", updated.getPhone());
		assertEquals("25 Ridgeway Pk", updated.getAddress());
	}
	
	@Test
	void testUpdateContactDoesNotExist() {
		ContactService service = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.updateFirstName("54321", "Jimothy");
		});
	}
	
	@Test
	void testUpdateFirstNameInvalid() {
		ContactService service = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.updateFirstName("12345", "JimothyBimothyTim");
		});
	}
	
	@Test
	void testUpdateLastNameInvalid() {
		ContactService service = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.updateLastName("12345", "FallonitaBonitaKawaii");
		});
	}
	
	@Test
	void testUpdatePhoneInvalid() {
		ContactService service = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.updatePhone("12345", "111");
		});
	}
	
	@Test
	void testUpdateAddressInvalid() {
		ContactService service = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.updateAddress("12345", "Across from the mcdonalds with the new but old mcrib thing they brought back from 2010 its so good");
		});
	}
}