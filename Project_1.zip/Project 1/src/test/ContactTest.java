package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import contactService.Contact;

class ContactTest {

	@Test
	void testContactClass() {
		Contact contactClass = new Contact("Jimmy", "Fallon", "12345", 
				"1112223333", "7 Maple Ave");
		assertTrue(contactClass.getFirstName().equals("Jimmy"));
		assertTrue(contactClass.getLastName().equals("Fallon"));
		assertTrue(contactClass.getId().equals("12345"));
		assertTrue(contactClass.getPhone().equals("1112223333"));
		assertTrue(contactClass.getAddress().equals("7 Maple Ave"));
	}
	
	@Test
	void testContactClassFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("JimothyAnneBeth", "Fallon", "12345", "1112223333",
					"11 maple ave");
			});
	}
	
	@Test
	void testContactClassLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Jimmy", "FallonitaBonita", "12345", "1112223333",
					"11 maple ave");
			});
	}
	
	@Test
	void testContactClassIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Jimothy", "Fallon", "11111123412334", "1112223333",
					"11 maple ave");
			});
	}
	
	@Test
	void testContactClassPhoneNotEqual() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Jimothy", "Fallon", "12345", "111111",
					"11 maple ave");
			});
	}
	
	@Test
	void testContactClassAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Jimothy", "Fallon", "12345", "1112223333",
					"11 maple ave but the right side of the street not the left");
			});
	}
	
	@Test
	void testContactClassLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Jimothy", null, "12345", "1112223333",
					"11 maple ave");
			});
	}
	
	@Test
	void testContactClassIdNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Jimothy", "Fallon", null, "1112223333",
					"11 maple ave");
			});
	}
	
	@Test
	void testContactClassPhoneNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Jimothy", "Fallon", "12345", null,
					"11 maple ave");
			});
	}
	
	@Test
	void testContactClassAddressNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Jimothy", "Fallon", "12345", "1112223333",
					null);
			});
	}
	
	@Test
	void testContactClassFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Fallon", "12345", "1112223333",
					"11 maple ave");
			});
	}


}
