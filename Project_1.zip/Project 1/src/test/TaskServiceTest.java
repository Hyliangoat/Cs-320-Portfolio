package test;

import static org.junit.jupiter.api.Assertions.*;
import taskService.Task;
import taskService.TaskService;

import org.junit.jupiter.api.Test;

class TaskServiceTest {

	@Test
	void testAddTask() {
		TaskService service = new TaskService();
		Task task = new Task("111", "Task", "Description");
		service.addTask(task);
	}
	
	@Test
	void testAddDuplicateTask() {
		TaskService service = new TaskService();
		Task task1 = new Task("111", "Task", "Description");
		Task task2 = new Task("111", "Task 2", "Description 2");
		
		service.addTask(task1);
		assertThrows(IllegalArgumentException.class, () -> {
			service.addTask(task2);
		});
	}
	
	@Test
	void testUpdateName() {
		TaskService service = new TaskService();
		Task task = new Task ("111", "Task", "Description");
		service.addTask(task);
		
		service.updateName("111", "Johnathan Cena");
		assertEquals("Johnathan Cena", task.getName());
	}
	
	@Test
	void testDeleteTask() {
		TaskService service = new TaskService();
		Task task = new Task ("111", "Task", "Description");
		service.addTask(task);
		service.deleteTask("111");
	}
	
	@Test
	void testUpdateDescription() {
		TaskService service = new TaskService();
		Task task = new Task ("111", "Task", "Description");
		service.addTask(task);
		
		service.updateDescription("111", "The GOAT");
		assertEquals("The GOAT", task.getDescription());
	}
	
	@Test
	void testUpdateNameInvalid() {
		TaskService service = new TaskService();
		Task task = new Task("111", "Task", "Description");
		service.addTask(task);
		
		assertThrows(IllegalArgumentException.class, () -> service.updateName("111", null));
		assertThrows(IllegalArgumentException.class, () -> service.updateName("111", "LongNameJohnsonEsquire"));
	}
	
	@Test
	void testUpdateDescriptionInvalid() {
		TaskService service = new TaskService();
		Task task = new Task("111", "Task", "Description");
		service.addTask(task);
		
		assertThrows(IllegalArgumentException.class, () -> service.updateDescription("111", null));
		assertThrows(IllegalArgumentException.class, () -> service.updateDescription("111", "Country roooooooooaaaaaaaaads take me hoooooooooooome, to a plaaaaaaaaaaace, I beloooooooooooong, WEST VIRGINIAAAAAAAAAAAAAAAA"));
	}
	
	@Test
	void testDeleteNonexistentTask() {
		TaskService service = new TaskService();
		Task task = new Task("111", "Task", "Description");
		service.addTask(task);
		
		assertThrows(IllegalArgumentException.class, () -> service.deleteTask("999"));
	}

}
