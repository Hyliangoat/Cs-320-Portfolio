package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import taskService.Task;

class TaskTest {

	@Test
	void testValidTask() {
		Task task = new Task("8675309", "Phonecall", "Call Jenny");
		assertEquals("8675309", task.getTaskID());
		assertEquals("Phonecall", task.getName());
		assertEquals("Call Jenny", task.getDescription());
	}
	
	@Test
	void testInvalidTaskID() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task(null, "Name", "Description");
		});
	}
	
	@Test
	void testInvalidName() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("8675309", null, "Description");
		});
	}
	
	@Test
	void testInvalidDescription() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("8675309", "Name", null);
		});
	}
	
	@Test
	void testTaskIDTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("10011101101101", "Mr Binary", "Buncha numbers");
		});
	}
	
	@Test
	void testNameTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("1232323", "The man of many nonsensical sequential patterns", "Buncha numbers");
		});
	}
	
	@Test
	void testDescriptionTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("11", "Eleven", "What really is the number 11? Is it two ones? The combination of 10 and 1? The combination of all real values in between 0 and 11 that make 11? These are the questions we are not asking our government. These are the secrets they keep from us.");
		});
	}

}
